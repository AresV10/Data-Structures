package structures;

import java.util.Iterator;

public class ScapegoatTree<T extends Comparable<T>> extends
		BinarySearchTree<T> {
	private int upperBound;


	@Override
	public void add(T t) {
		// TODO
	}

	@Override
	public boolean remove(T element) {
		// TODO
		return false;
	}
}
