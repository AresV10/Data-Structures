package structures;

import java.util.Iterator;

public class RecursiveList<T> implements ListInterface<String> {

	int size = 0;
	Node<String> head = null;
	String tempS="";
	String tempA="";
	String tempR="";
	int countX=0;
	
	public RecursiveList(){
		head = null;
		tempS="";
		tempA="";
		tempR="";
		countX=0;
		size=0;
	}
	
	@Override
	public Iterator<String> iterator() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return size;
	}

	@Override
	public ListInterface<String> insertFirst(String elem) {
		// TODO Auto-generated method stub
		size++;
		Node<String> addHead = new Node<String>(elem); 
		
		if(head == null) {
			head=addHead;
		}
		else {
			addHead.next = head;
			head = addHead;
		}
		
		return this;
	}

	@Override
	public ListInterface<String> insertLast(String elem) {
	
		Node<String> add = new Node<String>(elem);
		if(head==null) {
			head=add;
			size++;
			return this;
		}
		iterToEndToInsert(head, add);
		size++;
		return this;
	}
	
	//Helper method for insert last;
	public void iterToEndToInsert(Node<String> abcd, Node<String> addLast){
		if(abcd.next==null) {
			abcd.next = addLast;
			return;
		}
		iterToEndToInsert(abcd.next,addLast);
	}

	@Override
	public ListInterface<String> insertAt(int index, String elem) {
		// TODO Auto-generated method stub
		
		Node<String> add = new Node<String>(elem);
		if(index == 0) {
			insertFirst(elem);
			
		}
		else {
			
			iterToItemToInsert(index, head , add);
			size++;
			}
		
		
		return this;
	}
	
	//Helper method for insert at
	public void iterToItemToInsert(int x,Node<String> abcd , Node<String> addItem){
		if(x-1==0) {
			addItem.next = abcd.next;
			abcd.next = addItem;	
			return;
		}
		iterToItemToInsert(x-1,abcd.next,addItem);
	}

	@Override
	public String removeFirst() {
		// TODO Auto-generated method stub
		
		if(head==null) {
			throw new IllegalStateException();
		}
		
		Node<String> temp = head;
		head=head.next;
		
		size--;	
		return temp.data;
	}

	@Override
	public String removeLast() {
		// TODO Auto-generated method stub
		if(head==null) {
			throw new IllegalStateException();
		}
		iterToEndToRemove(head);
		
		size--;
		return tempS;
	}
	
	//Helper method for remove last;
		public void iterToEndToRemove(Node<String> abcd){
			if(abcd.next==null) {
				tempS = abcd.data;
				head=null;
				return;
				}
			if(abcd.next.next==null) {
				tempS = abcd.next.data;
				abcd.next=null;
				return;
			}
			
			iterToEndToRemove(abcd.next);
		}

	@Override
	public String removeAt(int i) {
		// TODO Auto-generated method stub
		if(i>=size||i<0) { 
			throw new IndexOutOfBoundsException();
		}
		else if(i==0) {
			if(head==null) {
				throw new IndexOutOfBoundsException();
			}
			removeFirst();
		}
		else if(i==size) {
			removeLast();
		}
		else {
		iterToItemToRemove(i,head);
		size--;}
		
		return tempA;
	}
	
	//Helper method for insert at
		public void iterToItemToRemove(int x,Node<String> abcd){
			if(x-1==0) {
				tempA = abcd.next.data;
				abcd.next = abcd.next.next;
				return;
			}
			iterToItemToRemove(x-1,abcd.next);
		}

	@Override
	public String getFirst() {
		// TODO Auto-generated method stub	
		if(head==null) {
			throw new IllegalStateException();
		}
		return head.data;
	}

	@Override
	public String getLast() {
		// TODO Auto-generated method stub
		if(head==null) {
			throw new IllegalStateException();
		}
		return get(size-1);
	}

	@Override
	public String get(int i) {
		// TODO Auto-generated method stub
		if(i>size||i<0) { throw new IndexOutOfBoundsException();}
		if(i==0) {
			return getFirst();
		}
				helpGet(i,head);

		return tempR;
	}
	
	//helper method for get
	
	public void helpGet(int x, Node<String> abcd) {
		if(x==0) {
			tempR = abcd.data;
			return;
		}
		helpGet(x-1, abcd.next);
	}

	@Override
	public boolean remove(String elem) {
		// TODO Auto-generated method stub
			int index = indexOf(elem);
			if (index == -1) return false;
			System.out.print(""+index);
			removeAt(index);
		return true;
	
	}

	@Override
	public int indexOf(String elem) {
		countX = 0;
		// TODO Auto-generated method stub
		indexOfHelp(elem,head);
		return countX;
	}

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return head==null;
	}
	
	public void indexOfHelp(String ree, Node<String> abcd) {
		if(abcd.next==null&&!abcd.data.equals(ree)) {
			countX=-1;
			return;		
		}
		if(abcd.data.equals(ree)) {
			return;
		}
		
		countX++;
		indexOfHelp(ree, abcd.next);
	}

}

class Node<T> {
	public T data;
	
	public Node<T> next;
	public Node(T data) { this.data=data;}
	public Node(T data, Node<T> next) {
		this.data = data; this.next=next;
	}
}

