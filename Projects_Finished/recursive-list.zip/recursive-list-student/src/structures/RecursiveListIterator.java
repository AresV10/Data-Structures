package structures;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class RecursiveListIterator<T> implements Iterator<T> {

	private Node<T> head;

	public RecursiveListIterator(Node<String> head2) {
		this.head = (Node<T>) head2;
	}

	@Override
	public boolean hasNext() {
		return head != null;
	}

	@Override
	public T next() throws NoSuchElementException {
		if (!hasNext()) {
			throw new NoSuchElementException();
		}
		T info = head.data;
		head = head.next;
		return info;
	}

	@Override
	public void remove() {
		throw new UnsupportedOperationException();
	}

}
