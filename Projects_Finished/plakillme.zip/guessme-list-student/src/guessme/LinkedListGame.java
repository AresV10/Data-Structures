package guessme;

/**
 * A LinkedList-based implementation of the Guess-A-Number game
 */
public class LinkedListGame {

	// TODO: declare data members as necessary
	private int guessCount;
	private int guess;
	boolean GameOver;
	LLIntegerNode candidates = null;
	LLIntegerNode guessList = null;
	


	/********************************************************
	 * NOTE: for this project you must use linked lists
	 * implemented by yourself. You are NOT ALLOWED to use
	 * Java arrays of any type, or any class in the java.util
	 * package (such as ArrayList).
	 *******************************************************/	 
	
	/********************************************************
	 * NOTE: you are allowed to add new methods if necessary,
	 * but DO NOT remove any provided method, and do NOT add
	 * new files (as they will be ignored by the autograder).
	 *******************************************************/
	
	// LinkedListGame constructor method
	public LinkedListGame() {
		// TODO
		candidates = new LLIntegerNode();
		guessList = new LLIntegerNode();
		LLIntegerNode updater = candidates;
		guessCount = 0;
		guess = 1000;
		for(int i = 1000; i<10000;i++) {
			updater.setInfo(i);
			updater.setLink(new LLIntegerNode());
			updater = updater.getLink();
			
		}
		GameOver = false;
	}
	
	// Resets data members and game state so we can play again
	public void reset() {
		// TODO
		candidates = new LLIntegerNode();
		LLIntegerNode updater = candidates;
		for(int i = 1000; i<10000;i++) {
			updater.setInfo(i);
			updater.setLink(new LLIntegerNode());
			updater = updater.getLink();
		}
		guessList = null;
		guessCount = 0;
		guess = 1000;
		GameOver = false;
	}
	
	// Returns true if n is a prior guess; false otherwise.
	public boolean isPriorGuess(int n) {
		// TODO
		LLIntegerNode updater = guessList;
		while(updater!=null) {
			if(n == updater.getInfo()) {
				return true;
			}
			updater = updater.getLink();
		}
		return false;
		
	}
	
	// Returns the number of guesses so far.
	public int numGuesses() {
		// TODO
		return guessCount;
	}
	
	/**
	 * Returns the number of matches between integers a and b.
	 * You can assume that both are 4-digits long (i.e. between 1000 and 9999).
	 * The return value must be between 0 and 4.
	 * 
	 * A match is the same digit at the same location. For example:
	 *   1234 and 4321 have 0 match;
	 *   1234 and 1114 have 2 matches (1 and 4);
	 *   1000 and 9000 have 3 matches (three 0's).
	 */
	public static int numMatches(int a, int b) {
		// TODO
		int nmatches = 0;

		if (a % 10 == b % 10)
			nmatches++;
		a = a / 10;
		b = b / 10;
		if (a % 10 == b % 10)
			nmatches++;
		a = a / 10;
		b = b / 10;
		if (a % 10 == b % 10)
			nmatches++;
		a = a / 10;
		b = b / 10;
		if (a % 10 == b % 10)
			nmatches++;
		a = a / 10;
		b = b / 10;

		return nmatches;
	}
	
	/**
	 * Returns true if the game is over; false otherwise.
	 * The game is over if the number has been correctly guessed
	 * or if no candidate is left.
	 */
	public boolean isOver() {
		// TODO
		return GameOver;
	}
	
	/**
	 * Returns the guess number and adds it to the list of prior guesses.
	 * The insertion should occur at the end of the prior guesses list,
	 * so that the order of the nodes follow the order of prior guesses.
	 */	
	public int getGuess() {
		// TODO: add guess to the list of prior guesses.
		guess = candidates.getInfo();
		
		LLIntegerNode updater = guessList;
		
		if(guessCount==0) {
			guessList = new LLIntegerNode();
			guessList.setInfo(guess);
			}
		else {
			while(updater.getLink()!=null) {
				updater = updater.getLink();
			}
			updater.setLink(new LLIntegerNode());
			updater = updater.getLink();
			updater.setInfo(guess);
		}
		
		guessCount++;
		return guess;
	}
	
	/**
	 * Updates guess based on the number of matches of the previous guess.
	 * If nmatches is 4, the previous guess is correct and the game is over.
	 * Check project description for implementation details.
	 * 
	 * Returns true if the update has no error; false if no candidate 
	 * is left (indicating a state of error);
	 */
	public boolean updateGuess(int nmatches) {
		// TODO
		LLIntegerNode updater = candidates;
		LLIntegerNode newTail = null;
		LLIntegerNode newHead = null;
		
		if (nmatches == 4) {
			GameOver = true;
		}
		while(updater!=null) {
			 if (numMatches(guess, updater.getInfo()) == nmatches) {//need to remove updater
				 
				 	 if(newTail == null) {
				 		newTail = new LLIntegerNode();
				 		newTail.setInfo(updater.getInfo());
				 		 newHead = newTail;
				 		 
				 	 }
				 	 
				 	 else {
				 		 LLIntegerNode plzHalp = new LLIntegerNode();
				 		 plzHalp.setInfo(updater.getInfo());
				 		newTail.setLink(plzHalp);
				 		newTail = plzHalp;
				 	 }
			 }
			 updater = updater.getLink();
		}
		candidates = newHead;

		if(candidates==null)
			return false;

		return true;
	}
	
	// Returns the head of the prior guesses list.
	// Returns null if there hasn't been any prior guess
	public LLIntegerNode priorGuesses() {
		// TODO
		//if(guessList!=null) {return null;}
		return guessList;
	}
	
	/**
	 * Returns the list of prior guesses as a String. For example,
	 * if the prior guesses are 1000, 2111, 3222, in that order,
	 * the returned string should be "1000, 2111, 3222", in the same order,
	 * with every two numbers separated by a comma and space, except the
	 * last number (which should not be followed by either comma or space).
	 *
	 * Returns an empty string if here hasn't been any prior guess
	 */
	public String priorGuessesString() {
		// TODO

		String priorGuesses = "";
		
		
		if(guessList!=null) {
			LLIntegerNode updater = guessList;
			priorGuesses = guessList.getInfo()+"";
			updater = guessList.getLink();
		
			while(updater != null) {
				priorGuesses = priorGuesses+", "+updater.getInfo();
				updater = updater.getLink();
			}
		}
		return priorGuesses;
	}
	


	/*
	 * public void removefromList(LLIntegerNode remove) { LLIntegerNode updater =
	 * candidates; LLIntegerNode previous = null;
	 * 
	 * while(updater!=null) { if(updater==remove) { break; } previous = updater;
	 * updater = updater.getLink(); } if(previous==null) { candidates =
	 * candidates.getLink(); } else { previous.setLink(updater.getLink()); } }
	 */

}

