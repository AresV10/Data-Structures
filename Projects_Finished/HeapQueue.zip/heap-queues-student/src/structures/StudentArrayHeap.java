package structures;

import java.util.Comparator;
import java.util.Iterator;

public class StudentArrayHeap<P, V> extends AbstractArrayHeap<P, V> {

	protected StudentArrayHeap(Comparator<P> comparator) {
		super(comparator);
		// TODO Auto-generated constructor stub
	}

	@Override
	protected int getLeftChildOf(int index) {
		// TODO Auto-generated method stub
		if (index < 0) throw new IndexOutOfBoundsException();
		return 2*index + 1;
	}

	@Override
	protected int getRightChildOf(int index) {
		// TODO Auto-generated method stub
		if (index < 0) throw new IndexOutOfBoundsException();
		return 2*index + 2;
	}

	@Override
	protected int getParentOf(int index) {
		// TODO Auto-generated method stub
		if (index < 1) throw new IndexOutOfBoundsException();
		return (index-1)/2;
	}

	@Override
	protected void bubbleUp(int index) {
		// TODO Auto-generated method stub
		Entry<P, V> temp = heap.get(index);
		int curr = index;
		int parent = (index-1)/2;
		Comparator<P> A = getComparator();
		while(curr>0 && A.compare(temp.getPriority(),heap.get(parent).getPriority()) > 0) {
			
			heap.set(curr, heap.get(parent));
			
			curr = parent;
			parent = (parent-1)/2;

		}
		heap.set(curr, temp);
		
	}

	@Override
	protected void bubbleDown(int index) {
		// TODO Auto-generated method stub
		int curr = index, larger;
		Entry<P, V> temp = heap.get(index);
		Comparator<P> A = getComparator();
		while(curr<heap.size()/2) {
			int leftChild = (2*curr)+1;
			int rightChild = (2*curr)+2;
			if(rightChild<heap.size() && A.compare(heap.get(leftChild).getPriority(),heap.get(rightChild).getPriority()) < 0) {
				larger = rightChild;
			}
			else {
				larger = leftChild;
			}
			
			if(A.compare(temp.getPriority(), heap.get(larger).getPriority())>=0) {
				break;
			}
			
			heap.set(curr, heap.get(larger));
			curr = larger;
		}
		
		heap.set(curr, temp);
	}
}
















