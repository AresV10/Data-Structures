package search;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

/**
 * An implementation of a Searcher that performs an iterative search,
 * storing the list of next states in a Queue. This results in a
 * breadth-first search.
 * 
 */
public class QueueBasedBreadthFirstSearcher<T> extends Searcher<T> {
	
	
	private final List<T> visited, pred, prev;
	private final Queue<T> q;
	
	

	public QueueBasedBreadthFirstSearcher(SearchProblem<T> searchProblem) {
		super(searchProblem);
		visited = new ArrayList<T>();
		pred = new ArrayList<T>();
		prev = new ArrayList<T>();
		q = new LinkedList<T>();
	}

	@Override
	public List<T> findSolution() {
        		// TODO
		if (solution != null) {
			return solution;
		}
		final T init = searchProblem.getInitialState();
		T curr = null;
		q.add(init);

		while (!q.isEmpty()) {
			T elem = q.poll();

			if (searchProblem.isGoal(elem)) {
				curr = elem;
				break;
			}

			visited.add(elem);

			for (T neighbor : searchProblem.getSuccessors(elem)) {if (!visited.contains(neighbor)) {
					q.add(neighbor);
					prev.add(neighbor);pred.add(elem);}
				}
			}
		final List<T> path = new ArrayList<T>();

		if (curr != null) {
	
			path.add(curr);
			while (!curr.equals(searchProblem.getInitialState())) {
				final T pre = pred.get(prev.indexOf(curr));
				path.add(pre);
				curr = pre;			}

			Collections.reverse(path);
		}
		if (path.size() > 0) {
			if (!isValidSolution(path)) {throw new NullPointerException();}}
		return path;
	}
}
