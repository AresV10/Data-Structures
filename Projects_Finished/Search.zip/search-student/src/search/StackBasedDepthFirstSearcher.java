package search;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Stack;

/**
 * An implementation of a Searcher that performs an iterative search,
 * storing the list of next states in a Stack. This results in a
 * depth-first search.
 * 
 */
public class StackBasedDepthFirstSearcher<T> extends Searcher<T> {
	
	
	private final List<T> visited, pred, prev;
	private final Stack<T> s;
	
	
	public StackBasedDepthFirstSearcher(SearchProblem<T> searchProblem) {
		super(searchProblem);
		visited = new ArrayList<T>();
		pred = new ArrayList<T>();
		prev = new ArrayList<T>();
		s = new Stack<T>();
		
	}

	@Override
	public List<T> findSolution() {
        		// TODO
		if (solution != null) {
			return solution;
		}
		final T init = searchProblem.getInitialState();
		T curr = null;
		s.push(init);

		while (!s.isEmpty()) {T elem = s.pop();

			if (searchProblem.isGoal(elem)) 
			{curr = elem;
				break;}

			visited.add(elem);

			for (T neighbor : searchProblem.getSuccessors(elem)) {
				if (!visited.contains(neighbor)) {s.push(neighbor);
					prev.add(neighbor);
					pred.add(elem);}}
		}
		final List<T> path = new ArrayList<T>();
		if (curr != null) {
			path.add(curr);
			while (!curr.equals(searchProblem.getInitialState())) {
				final T pre = pred.get(prev.indexOf(curr));
				path.add(pre);
				curr = pre;	
			}
			Collections.reverse(path);
		}
		if (path.size() > 0) {
			if (!isValidSolution(path)) {throw new NullPointerException();}
			}
		return path;
	}
}
