package largeinteger;

import largeinteger.LLNode;

/** The LargeInteger class
 *  This class represents a large, non-negative integer using a linked list.
 *  Each node stores a single digit. The nodes represent all digits in *reverse* order:
 *  the least significant digit is the first node, and the most significant the last node.
 *  For example, 135642 is represented as 2->4->6->5->3->1 in that order.
 */
public class LargeInteger {
	private LLNode<Integer> head;	// head of the list
	private int size;				// size (i.e. number of digits)
	LLNode<Integer> tail;
	
	// Returns size
	public int size() { return size; }
	// Returns the linked list (used only for JUnit test purpose)
	public LLNode<Integer> getList() { return head; }
	
	public LargeInteger() {
		head = null; size = 0;
	}
	
	/** Constructor that takes a String as input and constructs the linked list.
	 *  You can assume that the input is guaranteed to be valid: i.e. every character
	 *  in the string is between '0' and '9', and the first character is never '0'
	 *  (unless '0' is the only character in the string). You can use input.charAt(i)-'0'
	 *  to convert the character at index i to the integer value of that digit.
	 *  Remember: the list nodes must be in reverse order as the characters in the string.
	 */
	public LargeInteger(String input) {
		// TODO
		
		for(int i = input.length()-1; i >= 0; i--){
			LLNode<Integer> add = new LLNode<Integer>(input.charAt(i)-'0',null);
			
			if(head==null) {
				head = add;
				tail = head;
				size++;}
			else {
				tail.link=add;
				tail = tail.link;
				size++;
				}
		}
	}
	
	/** Divide *this* large integer by 10 and return this.
	 *  Assume integer division: for example, 23/10 = 2, 8/10 = 0 and so on.
	 */
	public LargeInteger divide10() {
		// TODO
		if(head.link==null) {
			head.data = 0;
		}
		else	{	
		head = head.link;
		size--;}
		
		return this;
	}
	
/** Multiply *this* large integer by 10 and return this.
	 *  For example, 23*10 = 230, 0*10 = 0 etc.
	 */
	public LargeInteger multiply10() {
		// TODO
		if(head.data==0 && head.link==null) {
			return this;
		}
		
		LLNode<Integer> add = new LLNode<Integer>(0, this.head);
		this.head = add;
		size++;
		return this;
	}
	
	/** Returns a *new* LargeInteger object representing the sum of this large integer
	 *  and another one (given by that). Your code must correctly handle cases such as
	 *  the two input integers have different sizes (e.g. 2+1000=1002), or there is a
	 *  carry over at the highest digit (e.g. 9999+2=10001). 
	 */
	public LargeInteger add(LargeInteger that) {
		// TODO
		LargeInteger addReturn = new LargeInteger();

		LLNode<Integer> curr = this.head;
		LLNode<Integer> currThat = that.head;
		LLNode<Integer> tail = null;

		int overflowAdd = 0;

		while (curr != null || currThat != null) {

			Integer add = (curr == null) ? 0 : curr.data;
			Integer addend = (currThat == null) ? 0 : currThat.data;
			int sum = add + addend + overflowAdd;

			LLNode<Integer> newNode = new LLNode<Integer>((sum) % 10, null);
			overflowAdd = sum / 10;
			if (tail == null)
				addReturn.head = newNode;
			else
				tail.link = newNode;
			tail = newNode;

			if (curr != null)
				curr = curr.link;
			if (currThat != null)
				currThat = currThat.link;

			addReturn.size++;
		}

		if (overflowAdd != 0) {
			tail.link = new LLNode<Integer>(overflowAdd, null);
			addReturn.size++;
		}

		return addReturn;
	}
	
	/** Returns a new LargeInteger object representing the result of multiplying
	 *  this large integer with a non-negative integer x. You can assume x is either
	 *  a positive integer or 0. Hint: you can use a loop and call the 'add' method
	 *  above to accomplish the 'multiply'.
	 */
	public LargeInteger multiply(int x) {
		// TODO
		
		//if multiply number is suppose 678, then write it as (8 + 70 + 600)
		//first i should take x and separate the numbers and add them into a large integer, so i can add them,
		//each step multiply by 10 and add
		LargeInteger multReturn = new LargeInteger();

		if (x == 0)
			return new LargeInteger("0");

		LLNode<Integer> curr = this.head;
		LLNode<Integer> tail = null;

		int overflowAdd = 0;

		while (curr != null) {
			Integer product = curr.data * x + overflowAdd;
			LLNode<Integer> currUpdate = new LLNode<Integer>((product) % 10, null);
			overflowAdd = (product) / 10;
			if (tail == null)
				multReturn.head = currUpdate;
			else
				tail.link = currUpdate;
			tail = currUpdate;

			multReturn.size++;

			curr = curr.link;
		}

		while (overflowAdd != 0) {
			LLNode<Integer> add = new LLNode<Integer>(overflowAdd % 10, null);
			tail.link = add;
			tail = add;
			overflowAdd /= 10;
			multReturn.size++;
		}

		return multReturn;
	}

	/** Recursive method that converts the list referenced by curr_node back to
	 *  a string representing the integer. Think about what's the base case and
	 *  what it should return. Then think about what it should return in non-base case.
	 *  Hint: refer to the 'printing a list backwards' example we covered in lectures.
	 */
	private String toString(LLNode<Integer> curr_node) {
		// TODO
		if(curr_node==null) {
			return "";
		}
		return toString(curr_node.link) + Integer.toString(curr_node.data);
	}
	
	/** Convert this list back to a string representing the large integer.
	 *  This is a public method that jump-starts the call to the recursive method above.
	 */
	public String toString() {
		return toString(head);
	}
	
	// Recursive method to compute factorial
	public static LargeInteger factorial(int n) {

		if(n==0) return new LargeInteger("1");
		return factorial(n-1).multiply(n);
	}
	
	// Recursive method to compute power
	public static LargeInteger pow(int x, int y) {
		if(y==0) return new LargeInteger("1");
		return pow(x, y-1).multiply(x);
	}
}
