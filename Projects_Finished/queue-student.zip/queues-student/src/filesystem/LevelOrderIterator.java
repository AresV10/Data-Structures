package filesystem;

import structures.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.NoSuchElementException;


/**
 * An iterator to perform a level order traversal of part of a 
 * filesystem. A level-order traversal is equivalent to a breadth-
 * first search.
 */
public class LevelOrderIterator extends FileIterator<File> {
	
	/**
	 * Instantiate a new LevelOrderIterator, rooted at the rootNode.
	 * @param rootNode
	 * @throws FileNotFoundException if the rootNode does not exist
	 */
	
	Queue<File> fileQ = new Queue<File>();
	public LevelOrderIterator(File rootNode) throws FileNotFoundException {
        	// TODO 1
		if(rootNode.exists())
		fileQ.enqueue(rootNode);
		else {
			throw new FileNotFoundException();
		}
	}
	
	@Override
	public boolean hasNext() {
        	// TODO 2
			if(fileQ.head==null) {
				return false;
			}
            return true;
	}

	@Override
	public File next() throws NoSuchElementException {
        	// TODO 3
			if(fileQ.peek().isFile()) {
				return fileQ.dequeue();
			}
			else if(fileQ.peek().isDirectory()){
				if(fileQ.peek().listFiles()==null) {
					return fileQ.dequeue();
				}
				else {
					File[] sorArr = fileQ.peek().listFiles();
					Arrays.sort(sorArr);
					for(File iter : sorArr) {
						fileQ.enqueue(iter);
					}
				}
			}
		return fileQ.dequeue();	
	}

	@Override
	public void remove() {
		// Leave this one alone.
		throw new UnsupportedOperationException();		
	}

}
