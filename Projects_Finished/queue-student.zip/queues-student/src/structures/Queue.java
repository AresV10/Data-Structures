package structures;

import java.util.NoSuchElementException;

import com.sun.org.apache.bcel.internal.generic.RET;

/**************************************************************************************
 * NOTE: before starting to code, check support/structures/UnboundedQueueInterface.java
 * for detailed explanation of each interface method, including the parameters, return
 * values, assumptions, and requirements
 ***************************************************************************************/
public class Queue<T> implements UnboundedQueueInterface<T> {

	
	int size = 0;
	public Node<T> head;
	private Node<T> tail;
	
	private Node<T> iterate; 
	
	public Queue() {		
            // TODO 1
		size=0;
		head = null;
		tail = null;
				
    }
	
	public Queue(Queue<T> other) {
            // TODO 2
		
		//size = other.size;
		//head = other.head;
		//tail = other.tail;
		
		Node<T> ptr = other.head;
		while (ptr != null) {
			this.enqueue(ptr.data);
			ptr = ptr.next;
		}
		
	}
	
	@Override
	public boolean isEmpty() {
            // TODO 3
            return head==null;
	}

	@Override
	public int size() {
            // TODO 4
            return size;
	}

	@Override
	public void enqueue(T element) {
            // TODO 5
		
			Node<T> add = new Node<T>(element, null);
			if(tail==null) {
				head = add;
				tail = add;
			}
			else {
				tail.next = add;
				tail = tail.next;
				
			}
		
			size++;
	}

	@Override
	public T dequeue() throws NoSuchElementException {
            // TODO 6
		if(head==null) {
			throw new NoSuchElementException();
		}
		else {
		Node<T> temp = head;
		head = head.next;
		if(head==null) {
			tail=null;
		}
			size--;
            return temp.data;}
	}

	@Override
	public T peek() throws NoSuchElementException {
            // TODO 7
			if(head==null) {
				throw new NoSuchElementException();
			}
			else
            return head.data;
	}

	
	@Override
	public UnboundedQueueInterface<T> reversed() {
            // TODO 8
		Queue<T> ret = new Queue<T>();
		helpReverse(head, ret);
            return ret;
	}
	
	private void helpReverse(Node<T> iterate, Queue<T> addTo ) {
		// TODO Auto-generated method stub
		if (iterate != null) {
			helpReverse(iterate.next, addTo);
			addTo.enqueue(iterate.data);
		}
			return ;
		}
}
	

class Node<T> {
	public T data;
	
	public Node<T> next;
	public Node(T data) { this.data=data;}
	public Node(T data, Node<T> next) {
		this.data = data; this.next=next;
	}
}

